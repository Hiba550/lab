%{
#include <stdio.h>
#include <stdlib.h>
int yylex();
void yyerror(const char *s) { printf("Invalid declaration\n"); }
%}

%token TYPE ID
%left ','

%%
decls:
    TYPE id_list ';' { printf("Valid declaration\n"); }
    ;
id_list:
    ID
    | id_list ',' ID
    ;
%%

int main() {
    printf("Enter variable name (press Enter to validate, Ctrl+C to stop)\n");
    yyparse();
    return 0;
}
