%{
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int yylex(void);
void yyerror(const char *s);

/* We'll use -1 to indicate "non-constant expression" */
%}

%union {
    int val;
    char *id;
}

%token <val> NUM
%token <id> ID
%type  <val> expr

%left '+' '-'
%left '*' '/'
%right UMINUS

%%

program:
      /* empty */
    | program stmt
    ;

stmt:
    ID '=' expr ';' {
        if ($3 != -1) {
            printf("Optimized: %s = %d;\n", $1, $3);
        } else {
            printf("Optimized: %s = expr;\n", $1);
        }
        free($1);
    }
    ;

expr:
      expr '+' expr {
          /* constant folding */
          if ($1 != -1 && $3 != -1) {
              $$ = $1 + $3;
          }
          /* algebraic simplification x + 0 -> x */
          else if ($1 == 0 && $3 == -1) {
              $$ = $3; /* but $3 is -1 (non-const) so keep -1 */
              $$ = -1;
          }
          else if ($3 == 0 && $1 == -1) {
              $$ = -1;
          } else if ($1 == 0 && $3 != -1) {
              $$ = $3;
          } else if ($3 == 0 && $1 != -1) {
              $$ = $1;
          } else {
              $$ = -1;
          }
      }
    | expr '-' expr {
          if ($1 != -1 && $3 != -1) {
              $$ = $1 - $3;
          } else if ($3 == 0 && $1 != -1) {
              $$ = $1;
          } else if ($1 == 0 && $3 != -1) {
              $$ = -$3;
          } else {
              $$ = -1;
          }
      }
    | expr '*' expr {
          /* constant folding */
          if ($1 != -1 && $3 != -1) {
              $$ = $1 * $3;
          }
          /* algebraic simplification: x * 1 -> x, x * 0 -> 0 */
          else if ($1 == 1 && $3 == -1) {
              $$ = -1;
          }
          else if ($3 == 1 && $1 == -1) {
              $$ = -1;
          }
          else if (($1 == 0 && $3 != -1) || ($3 == 0 && $1 != -1)) {
              $$ = 0;
          }
          /* strength reduction: multiply by 2 -> x + x (we can't fold to const) */
          else if ($1 == 2 && $3 == -1) {
              printf("Strength Reduction: replace (2 * var) with (var + var)\\n");
              $$ = -1;
          }
          else if ($3 == 2 && $1 == -1) {
              printf("Strength Reduction: replace (var * 2) with (var + var)\\n");
              $$ = -1;
          }
          else {
              $$ = -1;
          }
      }
    | expr '/' expr {
          if ($1 != -1 && $3 != -1 && $3 != 0) {
              $$ = $1 / $3;
          } else {
              $$ = -1;
          }
      }
    | '-' expr %prec UMINUS {
          if ($2 != -1) $$ = -($2);
          else $$ = -1;
      }
    | NUM {
          $$ = $1;
      }
    | ID {
          /* an identifier is non-constant for our simplistic optimizer */
          free($1);
          $$ = -1;
      }
    | '(' expr ')' {
          $$ = $2;
      }
    ;

%%

void yyerror(const char *s) {
    fprintf(stderr, "Parse error: %s\n", s ? s : "");
}

int main(void) {
    printf("=== Simple Code Optimizer (constant folding, algebraic simplification, strength reduction) ===\n");
    printf("Enter statements like: a = 2 + 3 * b;  (one per line). Press Ctrl+C to stop.\n");
    yyparse();
    return 0;
}
