%{
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* forward declarations */
int yylex(void);
void yyerror(const char *s);

/* simple symbol table (linked list) */
typedef struct Sym {
    char *name;
    char *type;
    struct Sym *next;
} Sym;

Sym *symtab = NULL;

void add_symbol(const char *name, const char *type) {
    Sym *s = (Sym*) malloc(sizeof(Sym));
    s->name = strdup(name);
    s->type = strdup(type);
    s->next = symtab;
    symtab = s;
}

char* get_type(const char *name) {
    Sym *s = symtab;
    while (s) {
        if (strcmp(s->name, name) == 0) return s->type;
        s = s->next;
    }
    return NULL;
}
%}

/* semantic value union */
%union {
    char *sval;
}

/* tokens with semantic types */
%token <sval> ID
%token <sval> INT_LITERAL FLOAT_LITERAL
%token INT FLOAT ASSIGN SEMI

/* non-terminals returning string type names */
%type <sval> type expr

%%

program:
    /* empty */
    | program stmt
    ;

stmt:
      decl SEMI
    | assign SEMI
    ;

decl:
    type ID {
        add_symbol($2, $1);
        printf("Declared %s as %s\n", $2, $1);
    }
    ;

assign:
    ID ASSIGN expr {
        char *declType = get_type($1);
        if (declType == NULL) {
            printf("Error: variable %s not declared\n", $1);
        } else if (strcmp(declType, $3) != 0) {
            printf("Type error: cannot assign %s to %s\n", $3, declType);
        } else {
            printf("Assignment OK: %s = %s\n", $1, $3);
        }
    }
    ;

type:
      INT   { $$ = strdup("int"); }
    | FLOAT { $$ = strdup("float"); }
    ;

expr:
      INT_LITERAL   { $$= strdup("int"); }
    | FLOAT_LITERAL { $$= strdup("float"); }
    | ID {
        char *t = get_type($1);
        if (t == NULL) {
            printf("Error: variable %s not declared\n", $1);
            $$ = strdup("undef");
        } else {
            $$ = strdup(t);
        }
    }
    ;

%%

int main(void) {
    printf("Enter declarations and assignments (one per line). Press Ctrl+D to finish.\n");
    yyparse();
    return 0;
}

void yyerror(const char *s) {
    fprintf(stderr, "Syntax error: %s\n", s);
}
