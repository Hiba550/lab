%{
#include <stdio.h>
#include <stdlib.h>
int yylex();
void yyerror(const char *s) { printf("Invalid arithmetic operation\n"); }
%}

%token NUMBER
%left '+' '-'
%left '*' '/'

%%
input:
    | input expr '\n' { printf("Result: %d\n", $2); }
    ;
expr:
      expr '+' expr   { $$ = $1 + $3; }
    | expr '-' expr   { $$ = $1 - $3; }
    | expr '*' expr   { $$ = $1 * $3; }
    | expr '/' expr   { $$ = $3 ? $1 / $3 : 0; }
    | '(' expr ')'    { $$ = $2; }
    | NUMBER          { $$ = $1; }
    ;
%%

int main() {
    printf("Calculator: Enter expression (press Enter to evaluate, Ctrl+C to stop)\n");
    yyparse();
    return 0;
}
