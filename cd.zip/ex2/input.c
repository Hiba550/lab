int x = 10;
if (x >= 5) {
  x = x + 1;
}
