%{
#include <stdio.h>
#include <stdlib.h>
int yylex();
void yyerror(const char *s) { printf("Invalid control statement\n"); }
%}

%token IF ELSE WHILE ID NUMBER
%left '(' ')'
%left '{' '}'

%%
stmt:
      IF '(' cond ')' stmt
    | IF '(' cond ')' stmt ELSE stmt
    | WHILE '(' cond ')' stmt
    | '{' stmt '}'
    | ID '=' expr ';'
    ;
cond: ID '<' NUMBER
    | ID '>' NUMBER
    | ID "==" NUMBER
    ;
expr: ID
    | NUMBER
    | expr '+' expr
    | expr '-' expr
    ;
%%

int main() {
    printf("Enter control snippet (press Enter to submit, Ctrl+C to stop)\n");
    yyparse();
    return 0;
}
