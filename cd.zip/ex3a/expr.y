%{
#include <stdio.h>
#include <stdlib.h>
int yylex();
void yyerror(const char *s) { printf("Invalid expression\n"); }
%}

%token NUMBER
%left '+' '-'
%left '*' '/'

%%
input:
    | input expr '\n' { printf("Valid expression\n"); }
    ;
expr:
      expr '+' expr
    | expr '-' expr
    | expr '*' expr
    | expr '/' expr
    | '(' expr ')'
    | NUMBER
    ;
%%

int main() {
    printf("Enter arithmetic expressions (press Enter to submit, Ctrl+C to stop)\n");
    yyparse();
    return 0;
}
